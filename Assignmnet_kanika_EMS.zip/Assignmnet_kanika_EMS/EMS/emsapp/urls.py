from django.urls import URLPattern, path
from .views import enquirycreate, enquirylist , enquirydetail , enquiryupdate , DeleteView , CustomLoginView , RegisterPage
from django.contrib.auth.views import LogoutView

urlpatterns = [
    path('login/' , CustomLoginView.as_view() , name='login'),
    path('logout/' , LogoutView.as_view(next_page = 'login') , name='logout'),
    path('register/', RegisterPage.as_view(), name='register'),
    path('', enquirylist.as_view(), name='enquiries'),
    path('enquiry/<int:pk>/', enquirydetail.as_view(), name='enquiry'),
    path('enquiry-create', enquirycreate.as_view(), name='enquiry-create'),
    path('enquiry-update/<int:pk>/', enquiryupdate.as_view(), name='enquiry-update'),
    path('enquiry-delete/<int:pk>/', DeleteView.as_view(), name='enquiry-delete'),
]