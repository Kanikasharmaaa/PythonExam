from django.contrib import admin
from .models import Enquiry

admin.site.register(Enquiry)
