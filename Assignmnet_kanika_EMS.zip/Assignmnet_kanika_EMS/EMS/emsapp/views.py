from dataclasses import field, fields
from re import template
from sre_constants import SUCCESS
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView , UpdateView , DeleteView , FormView
from django.urls import reverse_lazy
from django.shortcuts import render , redirect
from .models import Enquiry

from django.contrib.auth.views import LoginView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login


class CustomLoginView(LoginView):
    template_name = 'emsapp/login.html'
    fields = '__all__'
    redirect_authenticated_user = True

    def get_success_url(self):
        return reverse_lazy('enquiries')



class RegisterPage(FormView):
    template_name = 'emsapp/register.html'
    form_class = UserCreationForm
    redirect_authenticated_user = True
    success_url = reverse_lazy('enquiries')

    def form_valid(self, form):
        user = form.save()
        if user is not None:
            login(self.request, user)
        return super(RegisterPage, self).form_valid(form)

    def get(self, *args, **kwargs):
        if self.request.user.is_authenticated:
            return redirect('enquiries')
        return super(RegisterPage, self).get(*args, **kwargs)


class enquirylist(LoginRequiredMixin , ListView):
    model = Enquiry
    context_object_name = 'enquiries'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['enquiries'] = context['enquiries'].filter(user=self.request.user)
        context['count'] = context['enquiries'].filter(enquirydesc=False).count()

        search_input = self.request.GET.get('search-area') or ''
        if search_input:
            context['enquiries'] = context['enquiries'].filter(enquirydesc__startswith=search_input)    
        context['search_input'] = search_input
        return context



class enquirydetail(LoginRequiredMixin, DetailView):
    model = Enquiry
    context_object_name = 'enquiry'
    template_name = 'emsapp/enquiry.html'



class enquirycreate(LoginRequiredMixin, CreateView):
    model = Enquiry
    fields = ['course', 'enquirydesc']
    success_url = reverse_lazy('enquiries')

    def form_valid(self, form):
        form.instance.user= self.request.user
        return super(enquirycreate, self).form_valid(form)



class enquiryupdate(LoginRequiredMixin, UpdateView):
    model = Enquiry
    fields = ['course', 'enquirydesc']
    success_url = reverse_lazy('enquiries')



class DeleteView(LoginRequiredMixin, DeleteView):
    model = Enquiry
    context_object_name = 'enquiries'
    success_url = reverse_lazy('enquiries')



